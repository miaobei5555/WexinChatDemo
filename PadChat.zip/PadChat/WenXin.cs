﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace PadChat
{
    /// <summary>
    /// 作者 陌大北 QQ1078350533
    /// 承接一接软件开发
    /// </summary>
   public class WenXin
    {
       private long m_szCmdId = 0;
       private WebSocket4Net.WebSocket websocket;

       public WenXin(WebSocket4Net.WebSocket _websocket)
       {
           this.websocket = _websocket;
       }

       private string Pack(string cmd,Dictionary<string,object> dic)
       {
          
           WX_Info info=new WX_Info();
           info.type="user";
           info.cmd=cmd;
           info.cmdId= m_szCmdId + 1;
           info.payload = dic;

           string json = JsonConvert.SerializeObject(info);
            return json;
       }

       public void Init()
       {
            string json = Pack("init", null);
            Send(json);
       }

       public void Login()
       {
           Dictionary<string, object> dic = new Dictionary<string, object>();
           dic.Add("loginType", "qrcode");//扫码登录
           dic.Add("wxData", "");
           string json= Pack("login", dic);
           Send(json);
        
       }


       public void GetMyInfo()
       {
           string json = Pack("getMyInfo", null);
           Send(json);
       }


       private void Send(string json)
       {
           this.websocket.Send(json);
       }
    }



    public class WX_Info{
        public string type { get; set; }
        public string cmd { get; set; }
        public long cmdId { get; set; }
        public Dictionary<string, object> payload { get; set; }
    }
}
