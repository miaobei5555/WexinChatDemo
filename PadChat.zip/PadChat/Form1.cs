﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebSocket4Net;
using Newtonsoft.Json;
using System.IO;
namespace PadChat
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string url = "ws://47.99.211.34:8181";//"ws://123.207.167.163:9010/ajaxchattest";//在线测试websocket

        WebSocket websocket = null;
        WenXin wx = null;
        public delegate void text_delegate(string msg);
       
        private void Form1_Load(object sender, EventArgs e)
        {
           
            Init();

       
           

        }

        private void Init()
        {
            websocket = new WebSocket(url);
            websocket.Opened += new EventHandler(websocket_Opened);
            websocket.Error += new EventHandler<SuperSocket.ClientEngine.ErrorEventArgs>(websocket_Error);
            websocket.Closed += new EventHandler(websocket_Closed);
            websocket.MessageReceived += new EventHandler<MessageReceivedEventArgs>(websocket_MessageReceived);
            websocket.Open();
        }

        private void websocket_Opened(object sender, EventArgs e)
        {
            wx = new WenXin(websocket);

            wx.Init();
           
        }

        private void websocket_Closed(object sender, EventArgs e)
        {
         
        }

        private void websocket_MessageReceived(object sender, MessageReceivedEventArgs e)
        {
            Console.Write("服务器返回消息:"+e.GetHashCode()+"---"+e.Message);

             Wx_Unpack unpack=  JsonConvert.DeserializeObject<Wx_Unpack>(e.Message);

             if (unpack == null)
             {
                 throw new Exception("解析json异常 " + e.Message);
                
             }

             if (!unpack.type.Equals("userEvent"))
             {
              
                 //throw new Exception("未知的type "+unpack.type);
                 return;

             }

             switch (unpack.@event)
             {
                 case "qrcode":
                     string base64 = unpack.payload["base64"].ToString();
                     byte[] img = Convert.FromBase64String(base64);
                     Image newImage = null;
                     MemoryStream ms = new MemoryStream(img);
                     newImage = Image.FromStream(ms);
                     pictureBox1.Image = newImage;
                     break;
                 case "scan":

                     this.Invoke(new text_delegate(UpdateTxt),  unpack.payload["Msg"].ToString()); 
              
                     break;
                 case "login":
                     this.Invoke(new text_delegate(UpdateTxt), "登录成功"); 
                     wx.GetMyInfo();
                     break;
                 default:
                     Console.WriteLine(unpack.@event);
                     break;
             }


        }

        private void UpdateTxt(string msg){
            text_msg.Text = msg;
        }

        private void websocket_Error(object sender, SuperSocket.ClientEngine.ErrorEventArgs e)
        {
            Console.Write("websocket_Error:" + e.Exception.Message);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            wx.Login();
        }

    }


    public class Wx_Unpack{
        public string type { get; set; }
        public string @event { get; set; }
        public string taskId { get; set; }
        public Dictionary<string, object> payload { get; set; }

    }

}
